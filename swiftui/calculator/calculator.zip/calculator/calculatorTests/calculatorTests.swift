//
//  calculatorTests.swift
//  calculatorTests
//
//  Created by Kyle Cartier on 1/10/26.
//

import Testing
@testable import calculator

struct calculatorTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
